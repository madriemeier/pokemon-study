import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "./supabase.js";

// ── DATA ──────────────────────────────────────────────────────────────────────
const POKEMON_LINES = [
  { id: 1,  stages: [{ name: "Bulbasaur",  sprite: "1"   }, { name: "Ivysaur",    sprite: "2"   }, { name: "Venusaur",   sprite: "3"   }] },
  { id: 2,  stages: [{ name: "Charmander", sprite: "4"   }, { name: "Charmeleon", sprite: "5"   }, { name: "Charizard",  sprite: "6"   }] },
  { id: 3,  stages: [{ name: "Squirtle",   sprite: "7"   }, { name: "Wartortle",  sprite: "8"   }, { name: "Blastoise",  sprite: "9"   }] },
  { id: 4,  stages: [{ name: "Chikorita",  sprite: "152" }, { name: "Bayleef",    sprite: "153" }, { name: "Meganium",   sprite: "154" }] },
  { id: 5,  stages: [{ name: "Cyndaquil",  sprite: "155" }, { name: "Quilava",    sprite: "156" }, { name: "Typhlosion", sprite: "157" }] },
  { id: 6,  stages: [{ name: "Totodile",   sprite: "158" }, { name: "Croconaw",   sprite: "159" }, { name: "Feraligatr", sprite: "160" }] },
  { id: 7,  stages: [{ name: "Treecko",    sprite: "252" }, { name: "Grovyle",    sprite: "253" }, { name: "Sceptile",   sprite: "254" }] },
  { id: 8,  stages: [{ name: "Torchic",    sprite: "255" }, { name: "Combusken",  sprite: "256" }, { name: "Blaziken",   sprite: "257" }] },
  { id: 9,  stages: [{ name: "Mudkip",     sprite: "258" }, { name: "Marshtomp",  sprite: "259" }, { name: "Swampert",   sprite: "260" }] },
  { id: 10, stages: [{ name: "Turtwig",    sprite: "387" }, { name: "Grotle",     sprite: "388" }, { name: "Torterra",   sprite: "389" }] },
  { id: 11, stages: [{ name: "Chimchar",   sprite: "390" }, { name: "Monferno",   sprite: "391" }, { name: "Infernape",  sprite: "392" }] },
  { id: 12, stages: [{ name: "Piplup",     sprite: "393" }, { name: "Prinplup",   sprite: "394" }, { name: "Empoleon",   sprite: "395" }] },
];

const XP_THRESHOLDS = [0, 200, 500];

const TASKS = {
  basicas: [
    { id: "aula",             label: "Assistir aula",       xp: 30,  icon: "🎓" },
    { id: "tarefa_min",       label: "Tarefa mínima",       xp: 20,  icon: "📋" },
    { id: "tarefa_bonus",     label: "Tarefa bônus",        xp: 35,  icon: "⭐" },
    { id: "anki",             label: "Anki flashcards",     xp: 25,  icon: "🃏" },
    { id: "go_revisao",       label: "Revisão de GO",       xp: 20,  icon: "📖" },
    { id: "simulado",         label: "Simulado semanal",    xp: 60,  icon: "📝" },
  ],
  premium: [
    { id: "aula_antibiotico", label: "Aula de antibiótico", xp: 50,  icon: "💊" },
    { id: "aula_ecg",         label: "Aula de ECG",         xp: 50,  icon: "💓" },
    { id: "livro_antibiotico",label: "Livro antibiótico",   xp: 45,  icon: "📗" },
    { id: "livro_ecg",        label: "Livro de ECG",        xp: 45,  icon: "📘" },
    { id: "livro_gineco",     label: "Livro de gineco",     xp: 45,  icon: "📙" },
    { id: "livro_obstetricia",label: "Livro de obstetrícia",xp: 45,  icon: "📕" },
  ],
  vida: [
    { id: "exercicio",        label: "Exercício físico",    xp: 20,  icon: "🏊" },
    { id: "sono_7h",          label: "Dormir +7h",          xp: 15,  icon: "😴" },
    { id: "sono_score",       label: "Score sono >50",      xp: 10,  icon: "📊" },
    { id: "comer_bem",        label: "Comer bem",           xp: 15,  icon: "🥗" },
  ],
  penalidades: [
    { id: "comer_mal",        label: "Comi mal",            xp: -20, icon: "🍔" },
    { id: "dormir_menos_6",   label: "Dormi menos de 6h",   xp: -25, icon: "😵" },
  ],
};

const ALL_TASKS = [...TASKS.basicas, ...TASKS.premium, ...TASKS.vida, ...TASKS.penalidades];

const BADGES = [
  { id: "primeiro_dia",  icon: "🏅", label: "Primeira Insígnia",    desc: "Complete seu primeiro check-in",  check: s => s.total_days >= 1 },
  { id: "streak_3",      icon: "🔥", label: "Insígnia de Fogo",      desc: "3 dias seguidos",                  check: s => s.streak >= 3 },
  { id: "streak_7",      icon: "🪨", label: "Insígnia de Pedra",     desc: "7 dias seguidos",                  check: s => s.streak >= 7 },
  { id: "streak_30",     icon: "🥇", label: "Insígnia de Ouro",      desc: "30 dias seguidos",                 check: s => s.streak >= 30 },
  { id: "neurologia",    icon: "🧠", label: "Insígnia de Neurologia",desc: "Complete 10 simulados",           check: s => (s.task_counts?.simulado || 0) >= 10 },
  { id: "anki_master",   icon: "🃏", label: "Mestre do Anki",        desc: "50 sessões de Anki",               check: s => (s.task_counts?.anki || 0) >= 50 },
  { id: "atleta",        icon: "🏆", label: "Insígnia Atlética",     desc: "30 dias de exercício",             check: s => (s.task_counts?.exercicio || 0) >= 30 },
  { id: "ecg_expert",    icon: "💓", label: "Expert em ECG",         desc: "Aula + livro de ECG 5x cada",      check: s => (s.task_counts?.aula_ecg || 0) >= 5 && (s.task_counts?.livro_ecg || 0) >= 5 },
  { id: "evolucao",      icon: "✨", label: "Insígnia de Evolução",  desc: "Evolua seu Pokémon",               check: s => s.evolutions >= 1 },
  { id: "colecao",       icon: "📦", label: "Colecionadora",         desc: "Capture 2 Pokémons",               check: s => (s.collection || []).length >= 2 },
];

const PERF_BONUS = [
  { threshold: 0.9, xp: 40, label: "Excelente! +40 XP bônus" },
  { threshold: 0.7, xp: 20, label: "Bom! +20 XP bônus" },
  { threshold: 0.5, xp: 10, label: "+10 XP bônus" },
];

const IDLE_DECAY = 15;

// ── HELPERS ───────────────────────────────────────────────────────────────────
function getTodayKey() { return new Date().toISOString().split("T")[0]; }
function getStage(xp)  { if (xp >= XP_THRESHOLDS[2]) return 2; if (xp >= XP_THRESHOLDS[1]) return 1; return 0; }
function getSpriteUrl(id) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
}
function calcScore(xp, streak, badges) {
  return Math.round((xp || 0) * 0.6 + (streak || 0) * 50 + (badges || 0) * 30);
}
function generateId() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

// ── LOCAL STORAGE ─────────────────────────────────────────────────────────────
const LS_KEY = "pstudy_uid_v4";
function loadUID()     { try { return JSON.parse(localStorage.getItem(LS_KEY))?.uid || null; } catch { return null; } }
function saveUID(uid)  { localStorage.setItem(LS_KEY, JSON.stringify({ uid })); }

// ── GLOBAL CSS ────────────────────────────────────────────────────────────────
const globalCSS = `
  @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&family=Press+Start+2P&display=swap');
  @keyframes float   { 0%,100%{transform:translateY(0)}  50%{transform:translateY(-10px)} }
  @keyframes fadeUp  { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
  @keyframes slideIn { from{opacity:0;transform:translateX(64px)} to{opacity:1;transform:translateX(0)} }
  @keyframes evolve  { 0%{filter:brightness(1)} 45%{filter:brightness(14) saturate(0)} 100%{filter:brightness(1)} }
  @keyframes spin    { to{transform:rotate(360deg)} }
  @keyframes pop     { 0%{transform:scale(.85);opacity:0} 80%{transform:scale(1.05)} 100%{transform:scale(1);opacity:1} }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html, body, #root { height: 100%; }
  body { background: #080810; font-family: 'Nunito', sans-serif; color: #fff; }
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-thumb { background: #2a2a4a; border-radius: 2px; }
  input, button, select { font-family: 'Nunito', sans-serif; }
  button { cursor: pointer; }
`;

// ── COMPONENTS ────────────────────────────────────────────────────────────────
function Sprite({ spriteId, size = 120, animate = false, evolving = false, gray = false }) {
  return (
    <img
      src={getSpriteUrl(spriteId)}
      alt=""
      width={size}
      height={size}
      style={{
        display: "block",
        filter: gray
          ? "grayscale(1) brightness(.3)"
          : "drop-shadow(0 6px 20px rgba(230,57,70,.3))",
        animation: evolving
          ? "evolve 1.6s ease forwards"
          : animate ? "float 3s ease-in-out infinite" : "none",
        transition: "filter .3s",
      }}
    />
  );
}

function XPBar({ xp, stage }) {
  const next = XP_THRESHOLDS[stage + 1];
  if (!next) return <div style={{ color: "#ffd700", fontSize: 12, fontWeight: 700 }}>✨ Nível máximo!</div>;
  const prev = XP_THRESHOLDS[stage];
  const pct  = Math.min(100, ((xp - prev) / (next - prev)) * 100);
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#555", marginBottom: 5 }}>
        <span style={{ color: "#a8e6cf", fontWeight: 700 }}>{xp} XP</span>
        <span>próxima evolução: {next}</span>
      </div>
      <div style={{ background: "#111", borderRadius: 99, height: 8, overflow: "hidden", border: "1px solid #1e1e3a" }}>
        <div style={{ height: "100%", width: `${pct}%`, background: "linear-gradient(90deg,#e63946,#ffd700)", borderRadius: 99, transition: "width 1s cubic-bezier(.34,1.56,.64,1)", boxShadow: "0 0 8px rgba(230,57,70,.35)" }} />
      </div>
    </div>
  );
}

function Toast({ msg, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 3500); return () => clearTimeout(t); }, []);
  return (
    <div style={{ position: "fixed", top: 16, right: 16, zIndex: 9999, background: "linear-gradient(135deg,#12122a,#1a1a3e)", border: "1px solid #ffd700", borderRadius: 14, padding: "12px 17px", maxWidth: 270, boxShadow: "0 8px 28px rgba(0,0,0,.55)", animation: "slideIn .35s ease" }}>
      <div style={{ fontWeight: 800, color: "#ffd700", fontSize: 13, marginBottom: 3 }}>{msg.title}</div>
      <div style={{ color: "#bbb", fontSize: 12 }}>{msg.body}</div>
    </div>
  );
}

function Spinner({ size = 32 }) {
  return <div style={{ width: size, height: size, borderRadius: "50%", border: "3px solid #1e1e3a", borderTopColor: "#e63946", animation: "spin .8s linear infinite" }} />;
}

// ── APP ───────────────────────────────────────────────────────────────────────
export default function App() {
  const [uid,      setUid]      = useState(() => loadUID());
  const [user,     setUser]     = useState(null);
  const [friends,  setFriends]  = useState([]);
  const [screen,   setScreen]   = useState("home");
  const [loading,  setLoading]  = useState(true);
  const [toast,    setToast]    = useState(null);
  const [evolving, setEvolving] = useState(false);
  const queue = useRef([]);

  function pushToast(title, body) {
    queue.current.push({ title, body, id: Date.now() + Math.random() });
    if (!toast) setToast(queue.current.shift());
  }
  function nextToast() {
    if (queue.current.length) setToast(queue.current.shift());
    else setToast(null);
  }

  // ── load user ──
  useEffect(() => {
    if (!uid) { setLoading(false); return; }
    (async () => {
      const { data } = await supabase.from("users").select("*").eq("id", uid).single();
      if (!data) { setUid(null); saveUID(null); setLoading(false); return; }

      // idle decay
      const today = getTodayKey();
      if (data.last_checkin && data.last_checkin !== today) {
        const diff = Math.floor((new Date(today) - new Date(data.last_checkin)) / 86400000);
        if (diff > 0 && data.active_pokemon_line_id) {
          const col = (data.collection || []).map(c =>
            c.lineId === data.active_pokemon_line_id
              ? { ...c, xp: Math.max(0, c.xp - diff * IDLE_DECAY) }
              : c
          );
          const streak = diff > 1 ? 0 : data.streak;
          await supabase.from("users").update({ collection: col, streak }).eq("id", uid);
          data.collection = col;
          data.streak = streak;
        }
      }

      setUser(data);
      await refreshFriends(uid);
      setLoading(false);
    })();
  }, [uid]);

  async function refreshFriends(id) {
    const { data: links } = await supabase.from("friendships").select("friend_id").eq("user_id", id);
    if (!links?.length) { setFriends([]); return; }
    const ids = links.map(l => l.friend_id);
    const { data: fdata } = await supabase.from("users").select("*").in("id", ids);
    setFriends(fdata || []);
  }

  // ── polling every 30s ──
  useEffect(() => {
    if (!uid) return;
    const iv = setInterval(async () => {
      const { data } = await supabase.from("users").select("*").eq("id", uid).single();
      if (data) setUser(data);
      await refreshFriends(uid);
    }, 30000);
    return () => clearInterval(iv);
  }, [uid]);

  // ── badge check ──
  function applyBadges(u) {
    const earned = [...(u.earned_badges || [])];
    let changed = false;
    for (const b of BADGES) {
      if (!earned.includes(b.id) && b.check(u)) {
        earned.push(b.id);
        changed = true;
        setTimeout(() => pushToast("🏅 Nova insígnia!", `${b.icon} ${b.label}`), 500);
      }
    }
    return changed ? { ...u, earned_badges: earned } : u;
  }

  // ── register ──
  async function handleRegister(name, lineId) {
    setLoading(true);
    const id = generateId();
    const newUser = {
      id, name,
      total_xp: 0, streak: 0, last_checkin: null,
      active_pokemon_line_id: lineId,
      collection: [{ lineId, xp: 0 }],
      earned_badges: [], task_counts: {},
      total_days: 0, evolutions: 0,
    };
    const { error } = await supabase.from("users").insert(newUser);
    if (error) { pushToast("Erro", "Não foi possível criar conta."); setLoading(false); return; }
    saveUID(id);
    setUid(id);
    setUser(newUser);
    setLoading(false);
    pushToast("Bem-vinda, Treinadora!", `Boa sorte, ${name}!`);
  }

  // ── checkin ──
  async function handleCheckin(tasks, perfPct) {
    const today = getTodayKey();
    let xp = 0;
    const counts = { ...(user.task_counts || {}) };
    for (const [id, on] of Object.entries(tasks)) {
      if (!on) continue;
      const t = ALL_TASKS.find(x => x.id === id);
      if (t) { xp += t.xp; counts[id] = (counts[id] || 0) + 1; }
    }
    let bonusLabel = null;
    for (const b of PERF_BONUS) { if (perfPct >= b.threshold) { xp += b.xp; bonusLabel = b.label; break; } }

    const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
    const yKey = yesterday.toISOString().split("T")[0];
    const newStreak = user.last_checkin === yKey ? (user.streak || 0) + 1 : 1;

    const col = (user.collection || []).map(c => {
      if (c.lineId !== user.active_pokemon_line_id) return c;
      const oldXP  = c.xp;
      const newXP  = Math.max(0, oldXP + xp);
      const oldStg = getStage(oldXP);
      const newStg = getStage(newXP);
      if (newStg > oldStg) {
        setEvolving(true);
        const line = POKEMON_LINES.find(l => l.id === user.active_pokemon_line_id);
        setTimeout(() => {
          setEvolving(false);
          pushToast("🌟 Evolução!", `${line.stages[oldStg].name} → ${line.stages[newStg].name}!`);
        }, 1800);
      }
      return { ...c, xp: newXP };
    });

    let updated = {
      ...user,
      collection: col,
      total_xp: (user.total_xp || 0) + Math.max(0, xp),
      streak: newStreak,
      last_checkin: today,
      total_days: (user.total_days || 0) + 1,
      task_counts: counts,
      evolutions: (user.evolutions || 0),
    };
    updated = applyBadges(updated);

    setUser(updated);
    setScreen("home");
    await supabase.from("users").update({
      collection:             updated.collection,
      total_xp:               updated.total_xp,
      streak:                 updated.streak,
      last_checkin:           updated.last_checkin,
      total_days:             updated.total_days,
      task_counts:            updated.task_counts,
      earned_badges:          updated.earned_badges,
      evolutions:             updated.evolutions,
      active_pokemon_line_id: updated.active_pokemon_line_id,
    }).eq("id", uid);

    if (bonusLabel) setTimeout(() => pushToast("🎯 Bônus!", bonusLabel), 300);
    setTimeout(() => pushToast("✅ Check-in feito!", `+${Math.max(0, xp)} XP`), 80);
  }

  // ── capture ──
  async function handleCapture(lineId) {
    if ((user.collection || []).find(c => c.lineId === lineId)) return;
    const col = [...(user.collection || []), { lineId, xp: 0 }];
    let updated = applyBadges({ ...user, collection: col, active_pokemon_line_id: lineId });
    setUser(updated);
    await supabase.from("users").update({ collection: col, active_pokemon_line_id: lineId, earned_badges: updated.earned_badges }).eq("id", uid);
    const line = POKEMON_LINES.find(l => l.id === lineId);
    pushToast("📦 Capturado!", `${line.stages[0].name} entrou na coleção!`);
  }

  // ── set active ──
  async function handleSetActive(lineId) {
    setUser(u => ({ ...u, active_pokemon_line_id: lineId }));
    await supabase.from("users").update({ active_pokemon_line_id: lineId }).eq("id", uid);
  }

  // ── add friend ──
  async function handleAddFriend(name) {
    const { data } = await supabase.from("users").select("*").ilike("name", name).limit(1);
    if (!data?.length) { pushToast("Não encontrado", `Nenhum usuário com esse nome`); return false; }
    const friend = data[0];
    if (friend.id === uid) { pushToast("Ei!", "Você não pode se adicionar"); return false; }
    if (friends.find(f => f.id === friend.id)) { pushToast("Já adicionado!", `${friend.name} já está na lista`); return false; }
    await supabase.from("friendships").upsert({ user_id: uid, friend_id: friend.id });
    await supabase.from("friendships").upsert({ user_id: friend.id, friend_id: uid });
    setFriends(prev => [...prev, friend]);
    pushToast("👋 Amigo adicionado!", `${friend.name} entrou na liga!`);
    return true;
  }

  // ── derived ──
  const activePoke   = (user?.collection || []).find(c => c.lineId === user?.active_pokemon_line_id);
  const activeLine   = POKEMON_LINES.find(l => l.id === user?.active_pokemon_line_id);
  const stage        = activePoke ? getStage(activePoke.xp) : 0;
  const curPoke      = activeLine?.stages[stage];
  const todayDone    = user?.last_checkin === getTodayKey();

  // ── render ──
  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16, background: "#080810" }}>
      <style>{globalCSS}</style>
      <Spinner size={40} />
      <div style={{ color: "#444", fontSize: 13 }}>Conectando...</div>
    </div>
  );

  if (!uid || !user) return (
    <>
      <style>{globalCSS}</style>
      <Onboarding onRegister={handleRegister} />
    </>
  );

  return (
    <div style={{ background: "#080810", minHeight: "100vh", maxWidth: 480, margin: "0 auto" }}>
      <style>{globalCSS}</style>
      {toast && <Toast msg={toast} onDone={nextToast} />}

      {/* header */}
      <div style={{ background: "linear-gradient(180deg,#0a0a1a,transparent)", padding: "14px 18px 10px", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, zIndex: 10, backdropFilter: "blur(8px)" }}>
        <div>
          <div style={{ fontFamily: "'Press Start 2P'", fontSize: 9, color: "#e63946", letterSpacing: 1 }}>POKÉMON</div>
          <div style={{ fontFamily: "'Press Start 2P'", fontSize: 7, color: "#ffd700" }}>STUDY LEAGUE</div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <div style={{ background: "#0d0d1f", border: "1px solid #1e1e3a", borderRadius: 99, padding: "3px 10px", fontSize: 11, color: "#ffd700" }}>🔥 {user.streak || 0}</div>
          <div style={{ background: "#0d0d1f", border: "1px solid #1e1e3a", borderRadius: 99, padding: "3px 10px", fontSize: 11, color: "#a8e6cf" }}>⚡ {user.total_xp || 0}</div>
        </div>
      </div>

      {/* nav */}
      <div style={{ display: "flex", justifyContent: "space-around", padding: "5px 10px 0", borderBottom: "1px solid #1a1a2e" }}>
        {[["home","🏠","Início"],["checkin","✅","Check-in"],["colecao","📦","Coleção"],["insignias","🏅","Insígnias"],["ranking","🏆","Ranking"]].map(([key, icon, label]) => (
          <button key={key} onClick={() => setScreen(key)} style={{ background: screen === key ? "linear-gradient(135deg,#e63946,#c1121f)" : "transparent", border: "none", borderRadius: 9, padding: "5px 7px", color: screen === key ? "#fff" : "#555", fontSize: 9, display: "flex", flexDirection: "column", alignItems: "center", gap: 2, fontWeight: 800 }}>
            <span style={{ fontSize: 15 }}>{icon}</span>{label}
          </button>
        ))}
      </div>

      <div style={{ padding: "18px 16px 80px" }}>
        {screen === "home"      && <HomeScreen      user={user} activePoke={activePoke} activeLine={activeLine} curPoke={curPoke} stage={stage} evolving={evolving} todayDone={todayDone} onCheckin={() => setScreen("checkin")} />}
        {screen === "checkin"   && <CheckinScreen   todayDone={todayDone} todayTasks={user.today_tasks} onSubmit={handleCheckin} />}
        {screen === "colecao"   && <CollectionScreen user={user} onCapture={handleCapture} onSetActive={handleSetActive} />}
        {screen === "insignias" && <BadgesScreen     user={user} />}
        {screen === "ranking"   && <RankingScreen    user={user} friends={friends} onAddFriend={handleAddFriend} />}
      </div>
    </div>
  );
}

// ── ONBOARDING ────────────────────────────────────────────────────────────────
function Onboarding({ onRegister }) {
  const [step,     setStep]     = useState(1);
  const [name,     setName]     = useState("");
  const [selected, setSelected] = useState(null);
  const [busy,     setBusy]     = useState(false);

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", padding: "50px 22px 40px", maxWidth: 480, margin: "0 auto" }}>
      <div style={{ fontFamily: "'Press Start 2P'", fontSize: 11, color: "#e63946", marginBottom: 3 }}>POKÉMON</div>
      <div style={{ fontFamily: "'Press Start 2P'", fontSize: 8, color: "#ffd700", marginBottom: 48 }}>STUDY LEAGUE</div>

      {step === 1 && (
        <div style={{ width: "100%", animation: "fadeUp .4s ease" }}>
          <div style={{ fontSize: 22, fontWeight: 900, textAlign: "center", marginBottom: 8 }}>Bem-vinda, Treinadora!</div>
          <div style={{ color: "#555", fontSize: 13, textAlign: "center", marginBottom: 32 }}>Sua jornada para a residência começa aqui.</div>
          <div style={{ fontSize: 11, color: "#555", fontWeight: 700, letterSpacing: 1, marginBottom: 6 }}>SEU NOME NO JOGO</div>
          <input
            value={name} onChange={e => setName(e.target.value)}
            onKeyDown={e => e.key === "Enter" && name.trim().length >= 2 && setStep(2)}
            placeholder="ex: Marina"
            style={{ width: "100%", padding: "13px 15px", background: "#0d0d1f", border: "1px solid #1e1e3a", borderRadius: 11, color: "#fff", fontSize: 15, outline: "none", marginBottom: 8 }}
          />
          <div style={{ fontSize: 11, color: "#444", marginBottom: 20 }}>Seus amigos vão te buscar por esse nome exato</div>
          <button onClick={() => name.trim().length >= 2 && setStep(2)} style={{ width: "100%", padding: 13, background: name.trim().length >= 2 ? "linear-gradient(135deg,#e63946,#c1121f)" : "#111", border: "none", borderRadius: 11, color: "#fff", fontSize: 15, fontWeight: 800 }}>
            Continuar →
          </button>
        </div>
      )}

      {step === 2 && (
        <div style={{ width: "100%", animation: "fadeUp .4s ease" }}>
          <div style={{ fontSize: 20, fontWeight: 900, textAlign: "center", marginBottom: 6 }}>Escolha seu Pokémon</div>
          <div style={{ color: "#555", fontSize: 12, textAlign: "center", marginBottom: 24 }}>Ele evolui junto com você</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10, marginBottom: 28 }}>
            {POKEMON_LINES.map(line => (
              <button key={line.id} onClick={() => setSelected(line.id)} style={{ background: selected === line.id ? "linear-gradient(135deg,#1a1a3e,#12122a)" : "#0d0d1f", border: `2px solid ${selected === line.id ? "#ffd700" : "#1e1e3a"}`, borderRadius: 13, padding: "12px 6px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, transition: "all .18s" }}>
                <Sprite spriteId={line.stages[0].sprite} size={60} animate={selected === line.id} />
                <span style={{ fontSize: 9, fontWeight: 800, color: selected === line.id ? "#ffd700" : "#555" }}>{line.stages[0].name}</span>
              </button>
            ))}
          </div>
          <button
            onClick={async () => { if (!selected || busy) return; setBusy(true); await onRegister(name.trim(), selected); }}
            disabled={!selected || busy}
            style={{ width: "100%", padding: 13, background: selected ? "linear-gradient(135deg,#e63946,#c1121f)" : "#111", border: "none", borderRadius: 11, color: "#fff", fontSize: 15, fontWeight: 800 }}
          >
            {busy ? "Criando conta..." : "Começar jornada!"}
          </button>
        </div>
      )}
    </div>
  );
}

// ── HOME ──────────────────────────────────────────────────────────────────────
function HomeScreen({ user, activePoke, activeLine, curPoke, stage, evolving, todayDone, onCheckin }) {
  if (!activePoke || !curPoke) return null;
  return (
    <div style={{ animation: "fadeUp .4s ease" }}>
      <div style={{ background: "linear-gradient(135deg,#0a0a1f,#12122a)", border: "1px solid #1e1e3a", borderRadius: 20, padding: 24, marginBottom: 14, textAlign: "center", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at 50% 20%,rgba(230,57,70,.07),transparent 65%)", pointerEvents: "none" }} />
        <div style={{ fontSize: 10, color: "#444", fontWeight: 800, letterSpacing: 2, textTransform: "uppercase", marginBottom: 4 }}>Treinadora {user.name}</div>
        <div style={{ fontFamily: "'Press Start 2P'", fontSize: 11, color: "#ffd700", marginBottom: 16 }}>{curPoke.name}</div>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 4 }}>
          <Sprite spriteId={curPoke.sprite} size={140} animate={!evolving} evolving={evolving} />
        </div>
        <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 16 }}>
          {activeLine.stages.map((_, i) => (
            <div key={i} style={{ width: 26, height: 26, borderRadius: "50%", background: i <= stage ? "linear-gradient(135deg,#ffd700,#ff9f1c)" : "#111", border: `2px solid ${i <= stage ? "#ffd700" : "#222"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10 }}>
              {i <= stage ? "★" : "○"}
            </div>
          ))}
        </div>
        <XPBar xp={activePoke.xp} stage={stage} />
        <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
          {[["🔥", user.streak || 0, "Streak", "#ffd700"], ["⚡", user.total_xp || 0, "XP Total", "#a8e6cf"], ["🏅", (user.earned_badges || []).length, "Insígnias", "#c9b1ff"], ["📦", (user.collection || []).length, "Pokémons", "#ffb347"]].map(([ic, val, lbl, col]) => (
            <div key={lbl} style={{ flex: 1, background: "#0d0d1f", borderRadius: 10, padding: "8px 4px", textAlign: "center", border: "1px solid #1e1e3a" }}>
              <div style={{ fontSize: 17, fontWeight: 900, color: col }}>{val}</div>
              <div style={{ fontSize: 9, color: "#444", marginTop: 2 }}>{ic} {lbl}</div>
            </div>
          ))}
        </div>
      </div>
      <button onClick={onCheckin} style={{ width: "100%", padding: 15, borderRadius: 13, border: todayDone ? "1px solid #1a3a1a" : "none", background: todayDone ? "#0a1a0a" : "linear-gradient(135deg,#e63946,#c1121f)", color: "#fff", fontSize: 14, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
        {todayDone ? "✅ Ver check-in de hoje" : "⚡ Fazer check-in do dia"}
      </button>
    </div>
  );
}

// ── CHECKIN ───────────────────────────────────────────────────────────────────
function CheckinScreen({ todayDone, todayTasks, onSubmit }) {
  const [tasks, setTasks] = useState(todayDone ? (todayTasks || {}) : {});
  const [perf,  setPerf]  = useState(0.72);
  const toggle = id => { if (!todayDone) setTasks(p => ({ ...p, [id]: !p[id] })); };

  function calcXP() {
    let x = 0;
    for (const [id, on] of Object.entries(tasks)) { if (!on) continue; const t = ALL_TASKS.find(a => a.id === id); if (t) x += t.xp; }
    for (const b of PERF_BONUS) { if (perf >= b.threshold) { x += b.xp; break; } }
    return x;
  }

  function Row({ task }) {
    const on = !!tasks[task.id];
    return (
      <button onClick={() => toggle(task.id)} style={{ display: "flex", alignItems: "center", gap: 10, background: on ? (task.xp < 0 ? "#1f0808" : "#081f10") : "#0a0a18", border: `1px solid ${on ? (task.xp < 0 ? "#3a1010" : "#103a18") : "#1e1e3a"}`, borderRadius: 11, padding: "11px 13px", textAlign: "left", transition: "all .15s", width: "100%" }}>
        <div style={{ width: 20, height: 20, borderRadius: "50%", border: `2px solid ${on ? (task.xp < 0 ? "#e63946" : "#40c870") : "#333"}`, background: on ? (task.xp < 0 ? "#e63946" : "#40c870") : "transparent", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: "#fff", flexShrink: 0 }}>
          {on ? "✓" : ""}
        </div>
        <span style={{ fontSize: 15 }}>{task.icon}</span>
        <span style={{ flex: 1, color: "#ddd", fontSize: 13, fontWeight: 600 }}>{task.label}</span>
        <span style={{ fontSize: 12, fontWeight: 800, color: task.xp < 0 ? "#e63946" : task.xp > 40 ? "#ffd700" : "#a8e6cf" }}>{task.xp > 0 ? "+" : ""}{task.xp}</span>
      </button>
    );
  }

  function Section({ title, list, accent }) {
    return (
      <div style={{ marginBottom: 22 }}>
        <div style={{ fontSize: 10, fontWeight: 800, color: accent, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 10 }}>{title}</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>{list.map(t => <Row key={t.id} task={t} />)}</div>
      </div>
    );
  }

  return (
    <div style={{ animation: "fadeUp .4s ease" }}>
      <div style={{ fontSize: 18, fontWeight: 900, marginBottom: 2 }}>Check-in do dia</div>
      <div style={{ color: "#555", fontSize: 12, marginBottom: 22 }}>{todayDone ? "Você já fez check-in hoje ✅" : "Marque tudo que você fez"}</div>
      <Section title="Tarefas básicas"    list={TASKS.basicas}     accent="#a8e6cf" />
      <Section title="Tarefas premium ⭐" list={TASKS.premium}     accent="#ffd700" />
      <Section title="Vida saudável"      list={TASKS.vida}        accent="#c9b1ff" />
      <Section title="Penalidades"        list={TASKS.penalidades} accent="#e63946" />
      {!todayDone && (
        <>
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 10, fontWeight: 800, color: "#666", letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 10 }}>Desempenho nas questões</div>
            <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
              {[{ l: "Excelente 90%+", v: 0.92 }, { l: "Bom 70%+", v: 0.72 }, { l: "Ok 50%+", v: 0.52 }, { l: "Abaixo 50%", v: 0 }].map(o => (
                <button key={o.v} onClick={() => setPerf(o.v)} style={{ padding: "7px 12px", borderRadius: 9, fontSize: 12, fontWeight: 700, background: perf === o.v ? "linear-gradient(135deg,#e63946,#c1121f)" : "#0d0d1f", border: `1px solid ${perf === o.v ? "transparent" : "#1e1e3a"}`, color: "#fff" }}>{o.l}</button>
              ))}
            </div>
          </div>
          <div style={{ background: "#0a0a18", border: "1px solid #1e1e3a", borderRadius: 13, padding: 14, marginBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ fontSize: 13, color: "#555" }}>XP de hoje:</div>
            <div style={{ fontSize: 26, fontWeight: 900, color: calcXP() >= 0 ? "#ffd700" : "#e63946" }}>{calcXP() >= 0 ? "+" : ""}{calcXP()}</div>
          </div>
          <button onClick={() => onSubmit(tasks, perf)} style={{ width: "100%", padding: 15, background: "linear-gradient(135deg,#e63946,#c1121f)", border: "none", borderRadius: 13, color: "#fff", fontSize: 15, fontWeight: 800 }}>
            ⚡ Confirmar check-in
          </button>
        </>
      )}
    </div>
  );
}

// ── COLLECTION ────────────────────────────────────────────────────────────────
function CollectionScreen({ user, onCapture, onSetActive }) {
  return (
    <div style={{ animation: "fadeUp .4s ease" }}>
      <div style={{ fontSize: 18, fontWeight: 900, marginBottom: 3 }}>Coleção</div>
      <div style={{ color: "#555", fontSize: 12, marginBottom: 20 }}>{(user.collection || []).length}/{POKEMON_LINES.length} capturados</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 10 }}>
        {POKEMON_LINES.map(line => {
          const owned    = (user.collection || []).find(c => c.lineId === line.id);
          const isActive = user.active_pokemon_line_id === line.id;
          const stg      = owned ? getStage(owned.xp) : 0;
          const poke     = line.stages[stg];
          return (
            <div key={line.id} style={{ background: isActive ? "linear-gradient(135deg,#1a1a3e,#12122a)" : "#0a0a18", border: `1px solid ${isActive ? "#ffd700" : "#1e1e3a"}`, borderRadius: 16, padding: 14, textAlign: "center", opacity: owned ? 1 : 0.5, position: "relative" }}>
              {isActive && <div style={{ position: "absolute", top: 7, right: 7, background: "#ffd700", color: "#000", fontSize: 8, fontWeight: 900, borderRadius: 5, padding: "2px 5px" }}>ATIVO</div>}
              <div style={{ display: "flex", justifyContent: "center", marginBottom: 6 }}>
                <Sprite spriteId={poke.sprite} size={70} animate={isActive} gray={!owned} />
              </div>
              <div style={{ fontSize: 12, fontWeight: 800, color: isActive ? "#ffd700" : "#bbb" }}>{poke.name}</div>
              {owned && <div style={{ fontSize: 10, color: "#444", marginTop: 2 }}>{owned.xp} XP</div>}
              {!owned && <button onClick={() => onCapture(line.id)} style={{ marginTop: 8, padding: "5px 12px", background: "linear-gradient(135deg,#e63946,#c1121f)", border: "none", borderRadius: 7, color: "#fff", fontSize: 11, fontWeight: 700 }}>Capturar</button>}
              {owned && !isActive && <button onClick={() => onSetActive(line.id)} style={{ marginTop: 8, padding: "5px 12px", background: "#111", border: "1px solid #2a2a4a", borderRadius: 7, color: "#666", fontSize: 11, fontWeight: 700 }}>Ativar</button>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── BADGES ────────────────────────────────────────────────────────────────────
function BadgesScreen({ user }) {
  return (
    <div style={{ animation: "fadeUp .4s ease" }}>
      <div style={{ fontSize: 18, fontWeight: 900, marginBottom: 3 }}>Insígnias</div>
      <div style={{ color: "#555", fontSize: 12, marginBottom: 20 }}>{(user.earned_badges || []).length}/{BADGES.length} conquistadas</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 10 }}>
        {BADGES.map(b => {
          const earned = (user.earned_badges || []).includes(b.id);
          return (
            <div key={b.id} style={{ background: earned ? "linear-gradient(135deg,#12122a,#1a1a3e)" : "#080808", border: `1px solid ${earned ? "#ffd700" : "#181818"}`, borderRadius: 12, padding: "12px 10px", textAlign: "center", opacity: earned ? 1 : 0.38, position: "relative" }}>
              <div style={{ fontSize: 26, marginBottom: 4 }}>{b.icon}</div>
              <div style={{ fontSize: 11, fontWeight: 800, color: earned ? "#ffd700" : "#444" }}>{b.label}</div>
              <div style={{ fontSize: 10, color: "#444", marginTop: 2, lineHeight: 1.4 }}>{b.desc}</div>
              {earned && <div style={{ position: "absolute", top: 6, right: 7, fontSize: 9, color: "#ffd700" }}>✓</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── RANKING ───────────────────────────────────────────────────────────────────
function RankingScreen({ user, friends, onAddFriend }) {
  const [search,  setSearch]  = useState("");
  const [busy,    setBusy]    = useState(false);
  const [open,    setOpen]    = useState(false);

  const me  = { ...user, isMe: true, badges: (user.earned_badges || []).length };
  const all = [me, ...friends.map(f => ({ ...f, badges: (f.earned_badges || []).length }))].map(p => ({ ...p, score: calcScore(p.total_xp, p.streak, p.badges) })).sort((a, b) => b.score - a.score);

  async function submit() {
    if (!search.trim() || busy) return;
    setBusy(true);
    const ok = await onAddFriend(search.trim());
    if (ok) { setSearch(""); setOpen(false); }
    setBusy(false);
  }

  return (
    <div style={{ animation: "fadeUp .4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <div style={{ fontSize: 18, fontWeight: 900 }}>Ranking</div>
          <div style={{ fontSize: 11, color: "#444" }}>XP×0.6 + Streak×50 + Insígnias×30</div>
        </div>
        <button onClick={() => setOpen(o => !o)} style={{ background: "linear-gradient(135deg,#e63946,#c1121f)", border: "none", borderRadius: 9, padding: "8px 14px", color: "#fff", fontSize: 12, fontWeight: 800 }}>+ Amigo</button>
      </div>

      {/* meu código */}
      <div style={{ background: "#0a0a18", border: "1px solid #1e1e3a", borderRadius: 13, padding: 14, marginBottom: 16 }}>
        <div style={{ fontSize: 10, color: "#444", fontWeight: 800, letterSpacing: 1, marginBottom: 5 }}>SEU NOME PARA AMIGOS TE ADICIONAREM</div>
        <div style={{ fontFamily: "'Press Start 2P'", fontSize: 10, color: "#ffd700" }}>{user.name}</div>
      </div>

      {open && (
        <div style={{ background: "#0a0a18", border: "1px solid #1e1e3a", borderRadius: 13, padding: 14, marginBottom: 16, animation: "pop .3s ease" }}>
          <div style={{ fontSize: 12, color: "#666", fontWeight: 700, marginBottom: 10 }}>Buscar amigo pelo nome exato</div>
          <div style={{ display: "flex", gap: 8 }}>
            <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === "Enter" && submit()} placeholder="Nome do amigo..." style={{ flex: 1, padding: "10px 12px", background: "#111", border: "1px solid #2a2a4a", borderRadius: 8, color: "#fff", fontSize: 13, outline: "none" }} />
            <button onClick={submit} disabled={busy} style={{ padding: "10px 16px", background: "linear-gradient(135deg,#e63946,#c1121f)", border: "none", borderRadius: 8, color: "#fff", fontWeight: 800, fontSize: 13, minWidth: 56 }}>
              {busy ? "..." : "Add"}
            </button>
          </div>
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {all.map((p, i) => {
          const line   = POKEMON_LINES.find(l => l.id === p.active_pokemon_line_id);
          const stg    = line ? getStage((p.collection || []).find(c => c.lineId === p.active_pokemon_line_id)?.xp || 0) : 0;
          const sprite = line?.stages[stg]?.sprite;
          return (
            <div key={p.id || i} style={{ background: p.isMe ? "linear-gradient(135deg,#1a1a3e,#12122a)" : "#0a0a18", border: `1px solid ${p.isMe ? "#ffd700" : "#1e1e3a"}`, borderRadius: 15, padding: "13px 15px", display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ fontSize: 18, minWidth: 26, textAlign: "center" }}>{["🥇","🥈","🥉"][i] || <span style={{ fontSize: 11, color: "#333" }}>{i + 1}</span>}</div>
              {sprite
                ? <Sprite spriteId={sprite} size={44} />
                : <div style={{ width: 44, height: 44, borderRadius: "50%", background: "#111", border: "1px solid #222", display: "flex", alignItems: "center", justifyContent: "center" }}>?</div>
              }
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 800, fontSize: 14, color: p.isMe ? "#ffd700" : "#e0e0e0" }}>{p.name}{p.isMe && " (você)"}</div>
                <div style={{ fontSize: 10, color: "#444", marginTop: 2 }}>🔥 {p.streak || 0}d · ⚡ {p.total_xp || 0} · 🏅 {p.badges || 0}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 20, fontWeight: 900, color: "#a8e6cf" }}>{p.score}</div>
                <div style={{ fontSize: 9, color: "#333" }}>pts</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
